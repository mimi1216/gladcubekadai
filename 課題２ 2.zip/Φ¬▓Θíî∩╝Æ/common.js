var ctx = document.getElementById("myRadarChart");

var myRadarChart = new Chart(ctx, {
  type: 'radar',
  data: {
    labels: ['ライティング', 'タスク管理', 'コミュニケーション', 'タイピング', '集中力'],
    datasets: [{
      label: 'できる事できる事',
      data: [3, 3, 4, 2, 4],
      borderColor: 'red',
    }],
  },
  options: {
    plugins: {
      legend: {
        labels: {
          font: {
            size: 20, // ラベルのフォントサイズを設定
          },
        },
      },
    },
    scales: {
      r: {
        min: 0,
        max: 5,
        backgroundColor: 'snow',
        grid: {
          color: 'pink',
        },
        angleLines: {
          color: 'green',
        },
        pointLabels: {
          font: {
            size: 16,
          },
          color: 'blue',
        },
      },
    },
  },
});

myRadarChart.canvas.parentNode.style.height = '800px';
myRadarChart.canvas.parentNode.style.width = '800px';
